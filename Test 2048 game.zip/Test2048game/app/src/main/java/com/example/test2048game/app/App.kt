package com.example.test2048game.app

import android.app.Application
import com.example.test2048game.repository.AppRepository
import com.example.test2048game.settings.Settings

class App:Application() {
    override fun onCreate() {
        Settings.init(this)
        AppRepository.init(this)
        super.onCreate()
    }
}