package com.example.test2048game.model

enum class SideEnum {
    LEFT, UP, RIGHT, DOWN
}